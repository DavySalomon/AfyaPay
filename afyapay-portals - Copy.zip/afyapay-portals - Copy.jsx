import React, { useState } from "react";

// ── Design tokens (from AfyaPay overview doc) ──
const T = {
  ink: "#0D0D0D",
  paper: "#F7F5F0",
  steel: "#1C2B3A",
  teal: "#007A6E",
  tealLight: "#E0F2F0",
  tealMid: "#00A896",
  amber: "#D4820A",
  amberLight: "#FDF3E0",
  red: "#B83232",
  redLight: "#FBEAEA",
  muted: "#6B7280",
  rule: "#D1CBC0",
  surface: "#FFFFFF",
  surface2: "#F0EDE8",
  mono: "'IBM Plex Mono', monospace",
  body: "'Inter', sans-serif",
  display: "'Fraunces', serif",
};

// ── Mock data ──
const facilityClaims = [
  { id: "CLM-2026-04821", date: "Jun 18", amount: "RWF 4,200", status: "Approved" },
  { id: "CLM-2026-04820", date: "Jun 18", amount: "RWF 7,800", status: "Pending" },
  { id: "CLM-2026-04817", date: "Jun 17", amount: "RWF 2,100", status: "Exception", reason: "Service code mismatch — child ID 44120 not enrolled under this facility catchment as of visit date." },
  { id: "CLM-2026-04815", date: "Jun 16", amount: "RWF 5,500", status: "Paid" },
  { id: "CLM-2026-04812", date: "Jun 15", amount: "RWF 3,050", status: "Approved" },
  { id: "CLM-2026-04808", date: "Jun 15", amount: "RWF 9,400", status: "Exception", reason: "Duplicate claim ID detected — matches CLM-2026-04770 submitted Jun 12." },
  { id: "CLM-2026-04801", date: "Jun 14", amount: "RWF 1,800", status: "Paid" },
];

const facilityRows = [
  { name: "Remera Health Center", district: "Gasabo", claims: 147, rate: "2.7%", status: "Normal" },
  { name: "Kicukiro HC", district: "Kicukiro", claims: 203, rate: "11.3%", status: "Review" },
  { name: "Nyarugenge HC", district: "Nyarugenge", claims: 89, rate: "18.0%", status: "Flag" },
  { name: "Kimironko HC", district: "Gasabo", claims: 164, rate: "3.1%", status: "Normal" },
  { name: "Muhima District Hospital", district: "Nyarugenge", claims: 412, rate: "5.9%", status: "Normal" },
];

const rssbQueue = [
  { id: "CLM-2026-04808", facility: "Remera Health Center", district: "Gasabo", amount: "RWF 9,400", reason: "Duplicate claim ID — matches CLM-2026-04770" },
  { id: "CLM-2026-04779", facility: "Kicukiro HC", district: "Kicukiro", amount: "RWF 12,600", reason: "Service exceeds capitation threshold for enrollee" },
  { id: "CLM-2026-04766", facility: "Nyarugenge HC", district: "Nyarugenge", amount: "RWF 3,900", reason: "Enrollee CBHI status lapsed at visit date" },
  { id: "CLM-2026-04751", facility: "Nyarugenge HC", district: "Nyarugenge", amount: "RWF 6,200", reason: "Provider not credentialed for billed service code" },
];

const statusColor = (s) => {
  if (s === "Approved" || s === "Paid" || s === "Normal") return { fg: T.teal, bg: T.tealLight };
  if (s === "Pending" || s === "Review") return { fg: T.amber, bg: T.amberLight };
  if (s === "Exception" || s === "Flag") return { fg: T.red, bg: T.redLight };
  return { fg: T.muted, bg: T.surface2 };
};

function Badge({ status }) {
  const c = statusColor(status);
  return (
    <span
      style={{
        fontFamily: T.mono,
        fontSize: 10,
        fontWeight: 600,
        letterSpacing: "0.04em",
        textTransform: "uppercase",
        color: c.fg,
        background: c.bg,
        border: `1px solid ${c.fg}33`,
        borderRadius: 3,
        padding: "3px 8px",
        whiteSpace: "nowrap",
      }}
    >
      {status}
    </span>
  );
}

function Kpi({ value, label, tone }) {
  const color = tone === "amber" ? T.amber : tone === "red" ? T.red : tone === "teal" ? T.teal : T.steel;
  return (
    <div style={{ background: T.surface, border: `1px solid ${T.rule}`, borderRadius: 4, padding: "16px 20px", flex: 1, minWidth: 140 }}>
      <div style={{ fontFamily: T.mono, fontSize: 22, fontWeight: 600, color }}>{value}</div>
      <div style={{ fontSize: 10.5, color: T.muted, letterSpacing: "0.05em", textTransform: "uppercase", marginTop: 3 }}>{label}</div>
    </div>
  );
}

function Btn({ children, onClick, variant = "solid", tone = "teal", small }) {
  const toneColor = tone === "red" ? T.red : tone === "steel" ? T.steel : T.teal;
  const base = {
    fontFamily: T.body,
    fontSize: small ? 11.5 : 12.5,
    fontWeight: 600,
    padding: small ? "5px 10px" : "8px 16px",
    borderRadius: 4,
    cursor: "pointer",
    border: `1px solid ${toneColor}`,
    transition: "opacity .15s",
  };
  const style =
    variant === "solid"
      ? { ...base, background: toneColor, color: "#fff" }
      : { ...base, background: "transparent", color: toneColor };
  return (
    <button style={style} onClick={onClick} onMouseDown={(e) => (e.currentTarget.style.opacity = "0.8")} onMouseUp={(e) => (e.currentTarget.style.opacity = "1")}>
      {children}
    </button>
  );
}

function PageHeader({ title, action }) {
  return (
    <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 20 }}>
      <div style={{ fontFamily: T.display, fontSize: 22, fontWeight: 700, color: T.steel }}>{title}</div>
      {action}
    </div>
  );
}

function TableShell({ cols, children }) {
  return (
    <div style={{ background: T.surface, border: `1px solid ${T.rule}`, borderRadius: 4, overflow: "hidden" }}>
      <div style={{ display: "grid", gridTemplateColumns: cols, gap: 8, padding: "10px 18px", background: T.surface2, borderBottom: `1px solid ${T.rule}`, fontFamily: T.mono, fontSize: 10.5, fontWeight: 600, letterSpacing: "0.05em", textTransform: "uppercase", color: T.muted }}>
        {children}
      </div>
    </div>
  );
}

function Row({ cols, children, onClick }) {
  return (
    <div
      onClick={onClick}
      style={{
        display: "grid",
        gridTemplateColumns: cols,
        gap: 8,
        padding: "13px 18px",
        borderBottom: `1px solid ${T.rule}`,
        alignItems: "center",
        fontSize: 12.5,
        color: T.ink,
        background: T.surface,
        cursor: onClick ? "pointer" : "default",
      }}
      onMouseEnter={(e) => onClick && (e.currentTarget.style.background = T.surface2)}
      onMouseLeave={(e) => onClick && (e.currentTarget.style.background = T.surface)}
    >
      {children}
    </div>
  );
}

function Sidebar({ items, active, onSelect, portalLabel, facilityLabel }) {
  return (
    <div style={{ width: 208, background: T.surface2, borderRight: `1px solid ${T.rule}`, padding: "20px 0", flexShrink: 0 }}>
      <div style={{ padding: "0 18px 16px", borderBottom: `1px solid ${T.rule}`, marginBottom: 10 }}>
        <div style={{ fontFamily: T.mono, fontSize: 10, color: T.tealMid, letterSpacing: "0.08em", fontWeight: 600 }}>AFYAPAY</div>
        <div style={{ fontSize: 11.5, color: T.muted, marginTop: 3 }}>{facilityLabel}</div>
      </div>
      {items.map((it) => {
        const isActive = it.key === active;
        const enabled = it.enabled !== false;
        return (
          <div
            key={it.key}
            onClick={() => enabled && onSelect(it.key)}
            title={enabled ? "" : "Not included in this preview"}
            style={{
              display: "flex",
              alignItems: "center",
              gap: 9,
              padding: "9px 18px",
              fontSize: 12.5,
              fontWeight: isActive ? 600 : 500,
              color: !enabled ? "#B9B2A5" : isActive ? T.steel : T.muted,
              background: isActive ? T.surface : "transparent",
              borderLeft: isActive ? `3px solid ${T.teal}` : "3px solid transparent",
              cursor: enabled ? "pointer" : "default",
            }}
          >
            <div style={{ width: 5, height: 5, borderRadius: "50%", background: isActive ? T.teal : "#C8C2B7" }} />
            {it.label}
          </div>
        );
      })}
    </div>
  );
}

function Modal({ title, onClose, children }) {
  return (
    <div style={{ position: "fixed", inset: 0, background: "rgba(13,13,13,0.45)", display: "flex", alignItems: "center", justifyContent: "center", zIndex: 50 }} onClick={onClose}>
      <div style={{ background: T.surface, borderRadius: 6, width: 440, maxWidth: "90%", padding: 24, boxShadow: "0 12px 32px rgba(0,0,0,0.25)" }} onClick={(e) => e.stopPropagation()}>
        <div style={{ fontFamily: T.display, fontWeight: 700, fontSize: 17, color: T.steel, marginBottom: 14 }}>{title}</div>
        {children}
      </div>
    </div>
  );
}

// ── Facility Portal ──
function FacilityPortal() {
  const [page, setPage] = useState("dashboard");
  const [claims, setClaims] = useState(facilityClaims);
  const [modalClaim, setModalClaim] = useState(null);
  const [toast, setToast] = useState("");

  const nav = [
    { key: "dashboard", label: "Dashboard" },
    { key: "encounter", label: "New Encounter", enabled: false },
    { key: "claims", label: "Claims" },
    { key: "exceptions", label: "Exceptions", enabled: false },
    { key: "payments", label: "Payments", enabled: false },
    { key: "reports", label: "Reports", enabled: false },
    { key: "settings", label: "Settings", enabled: false },
  ];

  const exceptionCount = claims.filter((c) => c.status === "Exception").length;

  const resolveClaim = (id, action) => {
    setClaims((cs) => cs.map((c) => (c.id === id ? { ...c, status: "Pending" } : c)));
    setModalClaim(null);
    setToast(action === "resubmit" ? `${id} corrected and resubmitted.` : `Dispute raised for ${id}.`);
    setTimeout(() => setToast(""), 2500);
  };

  function showToast() {
    if (!toast) return null;
    return (
      <div style={{ position: "fixed", bottom: 20, right: 20, background: T.steel, color: "#fff", padding: "10px 16px", borderRadius: 4, fontSize: 12.5, boxShadow: "0 4px 12px rgba(0,0,0,0.2)", zIndex: 60 }}>
        {toast}
      </div>
    );
  }

  const claimsList = page === "dashboard" ? claims.slice(0, 4) : claims;

  return (
    <div style={{ display: "flex", flex: 1, minHeight: 0 }}>
      <Sidebar items={nav} active={page} onSelect={setPage} facilityLabel="Remera Health Center" />
      <div style={{ flex: 1, padding: "26px 30px", overflowY: "auto" }}>
        {page === "dashboard" && (
          <>
            <PageHeader
              title="Dashboard · June 2026"
              action={
                <div style={{ display: "flex", gap: 8 }}>
                  <Btn variant="outline">Export</Btn>
                  <Btn onClick={() => setPage("encounter")}>+ New Encounter</Btn>
                </div>
              }
            />
            <div style={{ display: "flex", gap: 14, marginBottom: 22, flexWrap: "wrap" }}>
              <Kpi value="RWF 2.4M" label="Pending payment" tone="teal" />
              <Kpi value={claims.length * 21} label="Claims this month" />
              <Kpi value={exceptionCount} label="Exceptions to resolve" tone={exceptionCount ? "amber" : "teal"} />
              <Kpi value="11 days" label="Avg. payment cycle" tone="teal" />
            </div>
          </>
        )}
        {page === "claims" && <PageHeader title="Claims" action={<Btn variant="outline">Export</Btn>} />}

        <TableShell cols="1.4fr 0.8fr 0.9fr 1fr 0.8fr">
          <div>Claim ID</div>
          <div>Date</div>
          <div>Amount</div>
          <div>Status</div>
          <div>Action</div>
        </TableShell>
        <div style={{ border: `1px solid ${T.rule}`, borderTop: "none", borderBottomLeftRadius: 4, borderBottomRightRadius: 4, overflow: "hidden" }}>
          {claimsList.map((c) => (
            <Row key={c.id} cols="1.4fr 0.8fr 0.9fr 1fr 0.8fr">
              <div style={{ fontFamily: T.mono, fontSize: 11, color: T.muted }}>{c.id}</div>
              <div>{c.date}</div>
              <div>{c.amount}</div>
              <div><Badge status={c.status} /></div>
              <div>
                {c.status === "Exception" ? (
                  <span style={{ color: T.red, fontSize: 11, fontWeight: 600, cursor: "pointer" }} onClick={() => setModalClaim(c)}>
                    Resolve →
                  </span>
                ) : c.status === "Paid" ? (
                  <span style={{ color: T.teal, fontSize: 11, cursor: "pointer" }}>Receipt</span>
                ) : (
                  <span style={{ color: T.teal, fontSize: 11, cursor: "pointer" }}>View</span>
                )}
              </div>
            </Row>
          ))}
        </div>

        {page === "encounter" && (
          <div style={{ marginTop: 24, color: T.muted, fontSize: 13 }}>New Encounter entry flow isn't built in this preview.</div>
        )}
      </div>

      {modalClaim && (
        <Modal title={`Resolve ${modalClaim.id}`} onClose={() => setModalClaim(null)}>
          <div style={{ fontSize: 13, color: T.muted, lineHeight: 1.6, marginBottom: 16 }}>{modalClaim.reason}</div>
          <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
            <Btn onClick={() => resolveClaim(modalClaim.id, "resubmit")}>Correct &amp; resubmit</Btn>
            <Btn variant="outline" onClick={() => resolveClaim(modalClaim.id, "dispute")}>Raise formal dispute</Btn>
            <Btn variant="outline" tone="steel" onClick={() => setModalClaim(null)}>Cancel</Btn>
          </div>
        </Modal>
      )}
      {showToast()}
    </div>
  );
}

// ── RSSB Admin Portal ──
function RssbPortal() {
  const [page, setPage] = useState("overview");
  const [queue, setQueue] = useState(rssbQueue);
  const [rulingClaim, setRulingClaim] = useState(null);
  const [reason, setReason] = useState("");
  const [toast, setToast] = useState("");

  const nav = [
    { key: "overview", label: "Overview" },
    { key: "pipeline", label: "Claims Pipeline", enabled: false },
    { key: "exceptions", label: "Exception Queue" },
    { key: "payments", label: "Payments", enabled: false },
    { key: "capitation", label: "Capitation Data", enabled: false },
    { key: "facilities", label: "Facilities", enabled: false },
    { key: "fraud", label: "Fraud Flags", enabled: false },
    { key: "reports", label: "Reports", enabled: false },
  ];

  function rule(action) {
    setQueue((q) => q.filter((c) => c.id !== rulingClaim.id));
    setToast(`${rulingClaim.id} ${action}${reason ? ` — "${reason}"` : ""}`);
    setRulingClaim(null);
    setReason("");
    setTimeout(() => setToast(""), 3000);
  }

  return (
    <div style={{ display: "flex", flex: 1, minHeight: 0 }}>
      <Sidebar items={nav} active={page} onSelect={setPage} facilityLabel="National View" />
      <div style={{ flex: 1, padding: "26px 30px", overflowY: "auto" }}>
        {page === "overview" && (
          <>
            <PageHeader title="National Overview · June 2026" action={<Btn>Generate Report</Btn>} />
            <div style={{ display: "flex", gap: 14, marginBottom: 22, flexWrap: "wrap" }}>
              <Kpi value="12,847" label="Claims this month" />
              <Kpi value="94.2%" label="Auto-approved rate" tone="teal" />
              <Kpi value={queue.length + 744} label="In exception queue" tone="amber" />
              <Kpi value="9.4 days" label="Avg. cycle time" tone="teal" />
            </div>
            <TableShell cols="1.6fr 0.9fr 0.7fr 1fr 0.9fr">
              <div>Facility</div>
              <div>District</div>
              <div>Claims</div>
              <div>Exception Rate</div>
              <div>Status</div>
            </TableShell>
            <div style={{ border: `1px solid ${T.rule}`, borderTop: "none", borderBottomLeftRadius: 4, borderBottomRightRadius: 4, overflow: "hidden" }}>
              {facilityRows.map((f) => (
                <Row key={f.name} cols="1.6fr 0.9fr 0.7fr 1fr 0.9fr">
                  <div style={{ fontWeight: 500 }}>{f.name}</div>
                  <div>{f.district}</div>
                  <div>{f.claims}</div>
                  <div style={{ color: statusColor(f.status).fg, fontFamily: T.mono, fontSize: 11.5 }}>{f.rate}</div>
                  <div><Badge status={f.status} /></div>
                </Row>
              ))}
            </div>
          </>
        )}

        {page === "exceptions" && (
          <>
            <PageHeader title="Exception Queue" action={<span style={{ fontSize: 12, color: T.muted }}>{queue.length} claims awaiting ruling</span>} />
            {queue.length === 0 ? (
              <div style={{ color: T.muted, fontSize: 13, padding: "40px 0", textAlign: "center", border: `1px dashed ${T.rule}`, borderRadius: 4 }}>
                Queue clear — no claims awaiting adjudication.
              </div>
            ) : (
              <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
                {queue.map((c) => (
                  <div key={c.id} style={{ background: T.surface, border: `1px solid ${T.rule}`, borderRadius: 4, padding: "16px 18px", display: "flex", justifyContent: "space-between", alignItems: "center", gap: 16 }}>
                    <div>
                      <div style={{ display: "flex", gap: 10, alignItems: "center", marginBottom: 4 }}>
                        <span style={{ fontFamily: T.mono, fontSize: 11.5, color: T.muted }}>{c.id}</span>
                        <span style={{ fontWeight: 600, fontSize: 13, color: T.steel }}>{c.facility}</span>
                        <span style={{ fontSize: 11.5, color: T.muted }}>{c.district}</span>
                      </div>
                      <div style={{ fontSize: 12.5, color: T.muted }}>{c.reason}</div>
                    </div>
                    <div style={{ display: "flex", gap: 8, alignItems: "center", flexShrink: 0 }}>
                      <span style={{ fontFamily: T.mono, fontSize: 13, fontWeight: 600, color: T.steel, marginRight: 6 }}>{c.amount}</span>
                      <Btn small onClick={() => setRulingClaim(c)}>Review</Btn>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </>
        )}
      </div>

      {rulingClaim && (
        <Modal title={`Rule on ${rulingClaim.id}`} onClose={() => setRulingClaim(null)}>
          <div style={{ fontSize: 12.5, color: T.muted, marginBottom: 4 }}>{rulingClaim.facility} · {rulingClaim.amount}</div>
          <div style={{ fontSize: 13, color: T.ink, lineHeight: 1.6, marginBottom: 14 }}>{rulingClaim.reason}</div>
          <textarea
            placeholder="Reason for ruling (recorded, visible to facility)"
            value={reason}
            onChange={(e) => setReason(e.target.value)}
            style={{ width: "100%", minHeight: 64, fontFamily: T.body, fontSize: 12.5, padding: 10, border: `1px solid ${T.rule}`, borderRadius: 4, marginBottom: 14, resize: "vertical" }}
          />
          <div style={{ display: "flex", gap: 8 }}>
            <Btn onClick={() => rule("approved")}>Approve</Btn>
            <Btn variant="outline" tone="red" onClick={() => rule("rejected")}>Reject</Btn>
            <Btn variant="outline" tone="steel" onClick={() => setRulingClaim(null)}>Cancel</Btn>
          </div>
        </Modal>
      )}
      {toast && (
        <div style={{ position: "fixed", bottom: 20, right: 20, background: T.steel, color: "#fff", padding: "10px 16px", borderRadius: 4, fontSize: 12.5, boxShadow: "0 4px 12px rgba(0,0,0,0.2)", zIndex: 60, maxWidth: 320 }}>
          {toast}
        </div>
      )}
    </div>
  );
}

export default function App() {
  const [portal, setPortal] = useState("facility");

  return (
    <div style={{ fontFamily: T.body, background: T.paper, color: T.ink, height: "100vh", display: "flex", flexDirection: "column" }}>
      <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=IBM+Plex+Mono:wght@400;500;600&family=Inter:wght@300;400;500;600&family=Fraunces:ital,opsz,wght@0,9..144,300;0,9..144,700;1,9..144,300&display=swap" />
      {/* Title bar */}
      <div style={{ background: T.steel, padding: "0 20px", height: 48, display: "flex", alignItems: "center", justifyContent: "space-between", flexShrink: 0 }}>
        <div style={{ display: "flex", alignItems: "center", gap: 14 }}>
          <div style={{ display: "flex", gap: 5 }}>
            <div style={{ width: 9, height: 9, borderRadius: "50%", background: "#E06C6C" }} />
            <div style={{ width: 9, height: 9, borderRadius: "50%", background: "#E0B96C" }} />
            <div style={{ width: 9, height: 9, borderRadius: "50%", background: "#6CBF8F" }} />
          </div>
          <div style={{ fontFamily: T.mono, fontSize: 12.5, color: "rgba(255,255,255,0.85)" }}>
            AfyaPay — {portal === "facility" ? "Facility Portal · Remera Health Center" : "RSSB Administrator Portal · National View"}
          </div>
        </div>
        <div style={{ display: "flex", background: "rgba(255,255,255,0.08)", borderRadius: 5, padding: 3 }}>
          {[
            { key: "facility", label: "Facility Portal" },
            { key: "rssb", label: "RSSB Admin Portal" },
          ].map((p) => (
            <button
              key={p.key}
              onClick={() => setPortal(p.key)}
              style={{
                fontFamily: T.mono,
                fontSize: 10.5,
                letterSpacing: "0.04em",
                textTransform: "uppercase",
                padding: "6px 12px",
                borderRadius: 4,
                border: "none",
                cursor: "pointer",
                background: portal === p.key ? T.tealMid : "transparent",
                color: portal === p.key ? "#062A26" : "rgba(255,255,255,0.6)",
                fontWeight: 600,
              }}
            >
              {p.label}
            </button>
          ))}
        </div>
      </div>

      {portal === "facility" ? <FacilityPortal /> : <RssbPortal />}
    </div>
  );
}
